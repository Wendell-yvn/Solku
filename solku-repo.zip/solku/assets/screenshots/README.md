# Screenshots

Tambahkan screenshot dari Figma dan hasil Maze di folder ini.

Nama file yang disarankan:
- figma-buyer-home.png
- figma-booking-flow.png
- figma-provider-dashboard.png
- maze-task-result-buyer.png
- maze-task-result-provider.png
- use-score-buyer.png
- use-score-provider.png
